# NoteKeeper

NoteKeeper is a sample Android application developed by following the course on Pluralsight 
by Jim Wilson "Understanding Android Application Basics".